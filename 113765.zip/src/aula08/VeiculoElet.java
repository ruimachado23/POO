package aula08;

public interface VeiculoElet {
    int autonomia(); 
    void carregar(int percentagem);
}
