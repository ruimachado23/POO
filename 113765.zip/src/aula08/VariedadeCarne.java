package aula08;

public enum VariedadeCarne {
    VACA, PORCO, PERU, FRANGO, OUTRA
}
