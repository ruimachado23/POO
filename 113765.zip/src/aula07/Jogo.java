package aula07;

public class Jogo {
    private double duracao;

    public Jogo(double duracao) {
        this.duracao = duracao;
    }

    public double getDuracao() {
        return this.duracao;
    }

    public void setDuracao(double duracao) {
        this.duracao = duracao;
    }
}
