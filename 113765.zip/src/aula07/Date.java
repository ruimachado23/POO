package aula07;

public abstract class Date{
    public abstract int getDay();
    public abstract int getMonth();
    public abstract int getYear();
    public abstract void increment();
    public abstract void decrement();
    public abstract String toString();
}

