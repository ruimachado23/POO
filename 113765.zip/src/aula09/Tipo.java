package aula09;

public enum Tipo {
    MILITAR, COMERCIAL
}
